# Lista de Tarefas - Sistema de Gerenciamento de Pagamentos de Estudantes

## Ajustes Solicitados
- [ ] Substituir pnpm por npm no projeto e documentação
- [ ] Remover dados fictícios pré-preenchidos
- [ ] Implementar persistência de dados com localStorage
- [ ] Adicionar funcionalidade para adicionar novos alunos
- [ ] Adicionar funcionalidade para excluir alunos
- [ ] Adicionar funcionalidade para editar/excluir pagamentos
- [ ] Revisar e remover importações não utilizadas
- [ ] Testar todas as funcionalidades após as alterações
- [ ] Preparar código atualizado para envio ao usuário
